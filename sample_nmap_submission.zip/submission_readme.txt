How to use this sample package
==============================
1. Review the HTML reports in a browser.
2. Edit the reports if your instructor expects different formatting or additional sections.
3. Attach the .nmap files and the HTML report into a zip for submission.
4. If you run real scans, replace the sample .nmap files with your actual outputs and re-run the provided parse/generate scripts.
